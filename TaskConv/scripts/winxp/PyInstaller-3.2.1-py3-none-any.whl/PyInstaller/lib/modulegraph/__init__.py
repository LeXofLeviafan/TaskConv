# For PyInstaller/lib/ define the version here, since there is no
# package-resource.
__version__ = '0.12.1'
# updated from leycec-modulegraph-1e8f74ef92a5'
